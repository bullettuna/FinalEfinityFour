# 未通过资格检查的 image1 编号实验

本目录仅保留用于追溯，不是发布工程，outflow 内的 BIT／HEX 不推荐下载。

实际发布继续使用 `releases/multiboot/image7_default_1_5/fpga/image1.bit/.hex`（源码 284106a），它已经具备 BOOT IMAGE／LOAD IMAGE 功能。原版全部 28 项 setup／hold 关系和 CDC 已通过。

本实验源码只替换了菜单渲染器以添加常驻编号 1，没有修改摄像头、DDR、ISP 或形状识别算法。重新布局曾在原有 DDR／形状识别路径出现负余量；后续综合优化实验又因复位信号区域容量导致布局失败。所有这些候选都未发布。综合及布局参数现已恢复原 image1 设置；此后未重新构建，旧 outflow 不代表恢复参数后的结果。
