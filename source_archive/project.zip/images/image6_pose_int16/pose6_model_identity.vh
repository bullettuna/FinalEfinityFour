localparam POSE6_MODEL_BYTES=161440;
localparam [31:0] POSE6_MODEL_CRC=32'hbbffdf52;
