create_clock -period 10.417 -name clk [get_ports {clk}]
