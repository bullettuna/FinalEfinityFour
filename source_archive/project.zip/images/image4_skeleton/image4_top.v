`timescale 1ns/1ps
// image4: white-background silhouette and snapshot skeleton diagnostics.
module image4_top (
`include "src/top/camera_board_ports.vh"
);
image4_platform #(
    .PERSON_BUILD(1'b1),
    .EDGE_BACKGROUND_BUILD(1'b0),
    .GRAY_MEDIAN_BUILD(1'b0),
    .RAW_REFINE_BUILD(1'b1),
    .PHOTO_TF_BUILD(1'b0),
    .ENABLE_PHOTO_TF(1'b0),
    .ENABLE_ADC(1'b0),
    .SHAPE_BUILD(1'b0),
    .COLOR_OVERLAY_BUILD(1'b0),
    .GRAY_EDGE_SPLIT_BUILD(1'b0),
    .DEFAULT_VIDEO_MODE(2'd0)
) u_platform (
`include "src/top/camera_board_connections.vh"
);
endmodule
