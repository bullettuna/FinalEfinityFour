# image6 首版构建交付包

此包保存已通过整数参考、RTL 回归和 Efinity 时序检查的四点推理位流、模型、固定测试输入与报告。

软件交付已完成。按用户要求，硬件调试/验收由用户自行负责；运行入口和验证脚本已准备好。

**尚未完成 image6 实板下载/实时验收。** JTAG 目标 ID 读取无效，未写入此位流；原有 FPGA 串口仍可响应。包内的 manifest 明确记录这三个状态，不应将仿真结果当成实板结果。

现有工作目录启动入口：

```powershell
cd E:\Efinity_Project\FPGA_GAME
powershell -ExecutionPolicy Bypass -File .\start-image6.ps1
```

脚本首先读取有效 Ti60 ID，再临时下载 image6、加载 DDR 权重、比较实板四点及热图 CRC。任一步失败都会停止，不启动替代电脑模型。JTAG 需要正常读取 `0x10660A79`。

归档内容：

- `bitstream/`：时序检查后的 bit 和对应 SHA/检查记录。
- `model/`：161440 字节模型上传文件、身份和完整数值合同。
- `test/`：256x144 UINT16 确定性输入和预期点位/输入/热图 CRC。
- `reports/`：布局、时序、外部 FT 预算和五项 RTL 仿真日志。
- `docs/`：电脑端运行与 HDL 架构说明。

源代码位于已有 FPGA_GAME 和 EfinityFPGAfour 工作目录，具体版本见 manifest。此包不含 Efinity/Vivado 安装程序或完整 Python 环境；跨机器部署需另准备驱动和运行环境。

资源：XLR 51%、RAM 72%、DSP 31%；保留 Canny，不使用 SD。权重在 DDR，断电丢失，当前由电脑上电后加载。没有写启动 Flash，也没有把 image6 加入第六个启动菜单槽位。
